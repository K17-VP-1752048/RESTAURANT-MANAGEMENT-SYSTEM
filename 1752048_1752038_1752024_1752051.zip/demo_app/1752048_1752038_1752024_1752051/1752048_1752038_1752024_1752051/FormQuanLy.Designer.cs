﻿namespace DangKy
{
    partial class FormQuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnCapnhatMon = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.txtTenMon = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbMonAn = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnThem = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtLoai = new System.Windows.Forms.TextBox();
            this.txtGiaInsert = new System.Windows.Forms.TextBox();
            this.txtTenMonInsert = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cbTT = new System.Windows.Forms.ComboBox();
            this.btnCapNhatTT = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.txtIDDH = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.txtDuongCN = new System.Windows.Forms.TextBox();
            this.txtPhuongCN = new System.Windows.Forms.TextBox();
            this.txtQuanCN = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnInsertCN = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.txtTPCN = new System.Windows.Forms.TextBox();
            this.txtSDTCN = new System.Windows.Forms.TextBox();
            this.txtTenCN = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.cbChiNhanh = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtUpDuong = new System.Windows.Forms.TextBox();
            this.txtUpPhuong = new System.Windows.Forms.TextBox();
            this.txtUpQuan = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.btnUpdateCN = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.txtUpTP = new System.Windows.Forms.TextBox();
            this.txtUpSDT = new System.Windows.Forms.TextBox();
            this.txtUpTenCN = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label27 = new System.Windows.Forms.Label();
            this.btnUpSoLuong = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.lblIDMon = new System.Windows.Forms.Label();
            this.lblChinhanh = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.lblSLThanhVien = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.tab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.SuspendLayout();
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tabPage1);
            this.tab.Controls.Add(this.tabPage2);
            this.tab.Controls.Add(this.tabPage3);
            this.tab.Controls.Add(this.tabPage4);
            this.tab.Controls.Add(this.tabPage5);
            this.tab.Controls.Add(this.tabPage6);
            this.tab.Controls.Add(this.tabPage7);
            this.tab.Location = new System.Drawing.Point(0, 3);
            this.tab.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(1202, 630);
            this.tab.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnCapnhatMon);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.txtDonGia);
            this.tabPage1.Controls.Add(this.txtTenMon);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.cbMonAn);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1194, 597);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Cập nhật món ăn";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnCapnhatMon
            // 
            this.btnCapnhatMon.Location = new System.Drawing.Point(46, 372);
            this.btnCapnhatMon.Name = "btnCapnhatMon";
            this.btnCapnhatMon.Size = new System.Drawing.Size(93, 34);
            this.btnCapnhatMon.TabIndex = 8;
            this.btnCapnhatMon.Text = "Cập nhật";
            this.btnCapnhatMon.UseVisualStyleBackColor = true;
            this.btnCapnhatMon.Click += new System.EventHandler(this.btnCapnhatMon_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(454, 114);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(541, 292);
            this.dataGridView1.TabIndex = 7;
            // 
            // txtDonGia
            // 
            this.txtDonGia.Location = new System.Drawing.Point(150, 268);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(192, 26);
            this.txtDonGia.TabIndex = 6;
            // 
            // txtTenMon
            // 
            this.txtTenMon.Location = new System.Drawing.Point(150, 190);
            this.txtTenMon.Name = "txtTenMon";
            this.txtTenMon.Size = new System.Drawing.Size(192, 26);
            this.txtTenMon.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 271);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Đơn giá";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 196);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Tên món";
            // 
            // cbMonAn
            // 
            this.cbMonAn.FormattingEnabled = true;
            this.cbMonAn.Location = new System.Drawing.Point(150, 114);
            this.cbMonAn.Name = "cbMonAn";
            this.cbMonAn.Size = new System.Drawing.Size(192, 28);
            this.cbMonAn.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Món ăn";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(425, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cập nhật món ăn";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnThem);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.txtLoai);
            this.tabPage2.Controls.Add(this.txtGiaInsert);
            this.tabPage2.Controls.Add(this.txtTenMonInsert);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1194, 597);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Thêm món ăn";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(56, 353);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 36);
            this.btnThem.TabIndex = 6;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(531, 112);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(474, 277);
            this.dataGridView2.TabIndex = 5;
            // 
            // txtLoai
            // 
            this.txtLoai.Location = new System.Drawing.Point(183, 261);
            this.txtLoai.Name = "txtLoai";
            this.txtLoai.Size = new System.Drawing.Size(165, 26);
            this.txtLoai.TabIndex = 4;
            // 
            // txtGiaInsert
            // 
            this.txtGiaInsert.Location = new System.Drawing.Point(183, 188);
            this.txtGiaInsert.Name = "txtGiaInsert";
            this.txtGiaInsert.Size = new System.Drawing.Size(165, 26);
            this.txtGiaInsert.TabIndex = 4;
            // 
            // txtTenMonInsert
            // 
            this.txtTenMonInsert.Location = new System.Drawing.Point(183, 112);
            this.txtTenMonInsert.Name = "txtTenMonInsert";
            this.txtTenMonInsert.Size = new System.Drawing.Size(165, 26);
            this.txtTenMonInsert.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(42, 267);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 20);
            this.label8.TabIndex = 3;
            this.label8.Text = "Loại món";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "Đơn giá";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "Tên món";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(423, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(227, 37);
            this.label5.TabIndex = 0;
            this.label5.Text = "Thêm món ăn";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.cbTT);
            this.tabPage3.Controls.Add(this.btnCapNhatTT);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.txtIDDH);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1194, 597);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Cập nhật trạng thái đơn hàng";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // cbTT
            // 
            this.cbTT.FormattingEnabled = true;
            this.cbTT.Items.AddRange(new object[] {
            "Tiep nhan",
            "Dang chuan bi",
            "Dang giao",
            "Hoan tat"});
            this.cbTT.Location = new System.Drawing.Point(206, 208);
            this.cbTT.Name = "cbTT";
            this.cbTT.Size = new System.Drawing.Size(186, 28);
            this.cbTT.TabIndex = 5;
            // 
            // btnCapNhatTT
            // 
            this.btnCapNhatTT.Location = new System.Drawing.Point(71, 309);
            this.btnCapNhatTT.Name = "btnCapNhatTT";
            this.btnCapNhatTT.Size = new System.Drawing.Size(93, 34);
            this.btnCapNhatTT.TabIndex = 4;
            this.btnCapNhatTT.Text = "Cập nhật";
            this.btnCapNhatTT.UseVisualStyleBackColor = true;
            this.btnCapNhatTT.Click += new System.EventHandler(this.btnCapNhatTT_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(516, 113);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 62;
            this.dataGridView3.RowTemplate.Height = 28;
            this.dataGridView3.Size = new System.Drawing.Size(481, 230);
            this.dataGridView3.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(67, 211);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Trạng thái";
            // 
            // txtIDDH
            // 
            this.txtIDDH.Location = new System.Drawing.Point(206, 113);
            this.txtIDDH.Name = "txtIDDH";
            this.txtIDDH.Size = new System.Drawing.Size(188, 26);
            this.txtIDDH.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(67, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "ID đơn hàng";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(357, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(437, 37);
            this.label9.TabIndex = 0;
            this.label9.Text = "Cập nhật trạng thái đơn hàng";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.txtDuongCN);
            this.tabPage4.Controls.Add(this.txtPhuongCN);
            this.tabPage4.Controls.Add(this.txtQuanCN);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.btnInsertCN);
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Controls.Add(this.txtTPCN);
            this.tabPage4.Controls.Add(this.txtSDTCN);
            this.tabPage4.Controls.Add(this.txtTenCN);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1194, 597);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Thêm chi nhánh";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // txtDuongCN
            // 
            this.txtDuongCN.Location = new System.Drawing.Point(234, 423);
            this.txtDuongCN.Name = "txtDuongCN";
            this.txtDuongCN.Size = new System.Drawing.Size(165, 26);
            this.txtDuongCN.TabIndex = 19;
            // 
            // txtPhuongCN
            // 
            this.txtPhuongCN.Location = new System.Drawing.Point(234, 341);
            this.txtPhuongCN.Name = "txtPhuongCN";
            this.txtPhuongCN.Size = new System.Drawing.Size(165, 26);
            this.txtPhuongCN.TabIndex = 19;
            // 
            // txtQuanCN
            // 
            this.txtQuanCN.Location = new System.Drawing.Point(234, 277);
            this.txtQuanCN.Name = "txtQuanCN";
            this.txtQuanCN.Size = new System.Drawing.Size(165, 26);
            this.txtQuanCN.TabIndex = 19;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(112, 423);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 20);
            this.label18.TabIndex = 18;
            this.label18.Text = "Đường";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(112, 347);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 20);
            this.label17.TabIndex = 17;
            this.label17.Text = "Phường";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(112, 283);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 20);
            this.label16.TabIndex = 16;
            this.label16.Text = "Quận";
            // 
            // btnInsertCN
            // 
            this.btnInsertCN.Location = new System.Drawing.Point(97, 485);
            this.btnInsertCN.Name = "btnInsertCN";
            this.btnInsertCN.Size = new System.Drawing.Size(75, 36);
            this.btnInsertCN.TabIndex = 15;
            this.btnInsertCN.Text = "Thêm";
            this.btnInsertCN.UseVisualStyleBackColor = true;
            this.btnInsertCN.Click += new System.EventHandler(this.btnInsertCN_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(582, 78);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 62;
            this.dataGridView4.RowTemplate.Height = 28;
            this.dataGridView4.Size = new System.Drawing.Size(474, 443);
            this.dataGridView4.TabIndex = 14;
            // 
            // txtTPCN
            // 
            this.txtTPCN.Location = new System.Drawing.Point(234, 206);
            this.txtTPCN.Name = "txtTPCN";
            this.txtTPCN.Size = new System.Drawing.Size(165, 26);
            this.txtTPCN.TabIndex = 11;
            // 
            // txtSDTCN
            // 
            this.txtSDTCN.Location = new System.Drawing.Point(234, 141);
            this.txtSDTCN.Name = "txtSDTCN";
            this.txtSDTCN.Size = new System.Drawing.Size(165, 26);
            this.txtSDTCN.TabIndex = 12;
            // 
            // txtTenCN
            // 
            this.txtTenCN.Location = new System.Drawing.Point(234, 78);
            this.txtTenCN.Name = "txtTenCN";
            this.txtTenCN.Size = new System.Drawing.Size(165, 26);
            this.txtTenCN.TabIndex = 13;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(93, 212);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 20);
            this.label12.TabIndex = 10;
            this.label12.Text = "Thành phố";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(138, 147);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 20);
            this.label13.TabIndex = 9;
            this.label13.Text = "Sđt";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(63, 84);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 20);
            this.label14.TabIndex = 8;
            this.label14.Text = "Tên chi nhánh";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(468, 14);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(262, 37);
            this.label15.TabIndex = 7;
            this.label15.Text = "Thêm chi nhánh";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.cbChiNhanh);
            this.tabPage5.Controls.Add(this.label26);
            this.tabPage5.Controls.Add(this.txtUpDuong);
            this.tabPage5.Controls.Add(this.txtUpPhuong);
            this.tabPage5.Controls.Add(this.txtUpQuan);
            this.tabPage5.Controls.Add(this.label19);
            this.tabPage5.Controls.Add(this.label20);
            this.tabPage5.Controls.Add(this.label21);
            this.tabPage5.Controls.Add(this.btnUpdateCN);
            this.tabPage5.Controls.Add(this.dataGridView5);
            this.tabPage5.Controls.Add(this.txtUpTP);
            this.tabPage5.Controls.Add(this.txtUpSDT);
            this.tabPage5.Controls.Add(this.txtUpTenCN);
            this.tabPage5.Controls.Add(this.label22);
            this.tabPage5.Controls.Add(this.label23);
            this.tabPage5.Controls.Add(this.label24);
            this.tabPage5.Controls.Add(this.label25);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1194, 597);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Cập nhật chi nhánh";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // cbChiNhanh
            // 
            this.cbChiNhanh.FormattingEnabled = true;
            this.cbChiNhanh.Location = new System.Drawing.Point(264, 86);
            this.cbChiNhanh.Name = "cbChiNhanh";
            this.cbChiNhanh.Size = new System.Drawing.Size(165, 28);
            this.cbChiNhanh.TabIndex = 36;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(98, 89);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 20);
            this.label26.TabIndex = 35;
            this.label26.Text = "ID chi nhánh";
            // 
            // txtUpDuong
            // 
            this.txtUpDuong.Location = new System.Drawing.Point(265, 445);
            this.txtUpDuong.Name = "txtUpDuong";
            this.txtUpDuong.Size = new System.Drawing.Size(165, 26);
            this.txtUpDuong.TabIndex = 32;
            // 
            // txtUpPhuong
            // 
            this.txtUpPhuong.Location = new System.Drawing.Point(265, 394);
            this.txtUpPhuong.Name = "txtUpPhuong";
            this.txtUpPhuong.Size = new System.Drawing.Size(165, 26);
            this.txtUpPhuong.TabIndex = 33;
            // 
            // txtUpQuan
            // 
            this.txtUpQuan.Location = new System.Drawing.Point(265, 330);
            this.txtUpQuan.Name = "txtUpQuan";
            this.txtUpQuan.Size = new System.Drawing.Size(165, 26);
            this.txtUpQuan.TabIndex = 34;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(143, 445);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 20);
            this.label19.TabIndex = 31;
            this.label19.Text = "Đường";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(143, 400);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(64, 20);
            this.label20.TabIndex = 30;
            this.label20.Text = "Phường";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(143, 336);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 20);
            this.label21.TabIndex = 29;
            this.label21.Text = "Quận";
            // 
            // btnUpdateCN
            // 
            this.btnUpdateCN.Location = new System.Drawing.Point(128, 507);
            this.btnUpdateCN.Name = "btnUpdateCN";
            this.btnUpdateCN.Size = new System.Drawing.Size(121, 36);
            this.btnUpdateCN.TabIndex = 28;
            this.btnUpdateCN.Text = "Cập nhật";
            this.btnUpdateCN.UseVisualStyleBackColor = true;
            this.btnUpdateCN.Click += new System.EventHandler(this.btnUpdateCN_Click);
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(613, 100);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 62;
            this.dataGridView5.RowTemplate.Height = 28;
            this.dataGridView5.Size = new System.Drawing.Size(474, 443);
            this.dataGridView5.TabIndex = 27;
            // 
            // txtUpTP
            // 
            this.txtUpTP.Location = new System.Drawing.Point(265, 259);
            this.txtUpTP.Name = "txtUpTP";
            this.txtUpTP.Size = new System.Drawing.Size(165, 26);
            this.txtUpTP.TabIndex = 24;
            // 
            // txtUpSDT
            // 
            this.txtUpSDT.Location = new System.Drawing.Point(265, 194);
            this.txtUpSDT.Name = "txtUpSDT";
            this.txtUpSDT.Size = new System.Drawing.Size(165, 26);
            this.txtUpSDT.TabIndex = 25;
            // 
            // txtUpTenCN
            // 
            this.txtUpTenCN.Location = new System.Drawing.Point(264, 137);
            this.txtUpTenCN.Name = "txtUpTenCN";
            this.txtUpTenCN.Size = new System.Drawing.Size(165, 26);
            this.txtUpTenCN.TabIndex = 26;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(124, 265);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(85, 20);
            this.label22.TabIndex = 23;
            this.label22.Text = "Thành phố";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(169, 200);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(34, 20);
            this.label23.TabIndex = 22;
            this.label23.Text = "Sđt";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(98, 140);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(109, 20);
            this.label24.TabIndex = 21;
            this.label24.Text = "Tên chi nhánh";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(512, 28);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(315, 37);
            this.label25.TabIndex = 20;
            this.label25.Text = "Cập nhật chi nhánh";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.btnUpSoLuong);
            this.tabPage6.Controls.Add(this.numericUpDown1);
            this.tabPage6.Controls.Add(this.comboBox2);
            this.tabPage6.Controls.Add(this.comboBox1);
            this.tabPage6.Controls.Add(this.dataGridView6);
            this.tabPage6.Controls.Add(this.lblSoLuong);
            this.tabPage6.Controls.Add(this.lblIDMon);
            this.tabPage6.Controls.Add(this.lblChinhanh);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1194, 597);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Cập nhật số lượng món";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(304, 24);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(544, 37);
            this.label27.TabIndex = 33;
            this.label27.Text = "Cập nhật số lượng món trong ngày";
            // 
            // btnUpSoLuong
            // 
            this.btnUpSoLuong.Location = new System.Drawing.Point(240, 336);
            this.btnUpSoLuong.Name = "btnUpSoLuong";
            this.btnUpSoLuong.Size = new System.Drawing.Size(170, 44);
            this.btnUpSoLuong.TabIndex = 32;
            this.btnUpSoLuong.Text = "Cập nhật số lượng";
            this.btnUpSoLuong.UseVisualStyleBackColor = true;
            this.btnUpSoLuong.Click += new System.EventHandler(this.btnUpSoLuong_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(240, 243);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(186, 26);
            this.numericUpDown1.TabIndex = 31;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(240, 178);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(186, 28);
            this.comboBox2.TabIndex = 30;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(240, 114);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(186, 28);
            this.comboBox1.TabIndex = 29;
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(580, 96);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowHeadersWidth = 62;
            this.dataGridView6.RowTemplate.Height = 28;
            this.dataGridView6.Size = new System.Drawing.Size(499, 466);
            this.dataGridView6.TabIndex = 28;
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Location = new System.Drawing.Point(119, 247);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(72, 20);
            this.lblSoLuong.TabIndex = 5;
            this.lblSoLuong.Text = "Số lượng";
            // 
            // lblIDMon
            // 
            this.lblIDMon.AutoSize = true;
            this.lblIDMon.Location = new System.Drawing.Point(122, 181);
            this.lblIDMon.Name = "lblIDMon";
            this.lblIDMon.Size = new System.Drawing.Size(61, 20);
            this.lblIDMon.TabIndex = 4;
            this.lblIDMon.Text = "ID Món";
            // 
            // lblChinhanh
            // 
            this.lblChinhanh.AutoSize = true;
            this.lblChinhanh.Location = new System.Drawing.Point(119, 122);
            this.lblChinhanh.Name = "lblChinhanh";
            this.lblChinhanh.Size = new System.Drawing.Size(104, 20);
            this.lblChinhanh.TabIndex = 1;
            this.lblChinhanh.Text = "ID Chi Nhánh";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.button1);
            this.tabPage7.Controls.Add(this.lblSLThanhVien);
            this.tabPage7.Controls.Add(this.label28);
            this.tabPage7.Controls.Add(this.dataGridView7);
            this.tabPage7.Location = new System.Drawing.Point(4, 29);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1194, 597);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Xem thành viên";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(496, 501);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 50);
            this.button1.TabIndex = 36;
            this.button1.Text = "Load";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblSLThanhVien
            // 
            this.lblSLThanhVien.AutoSize = true;
            this.lblSLThanhVien.Location = new System.Drawing.Point(95, 516);
            this.lblSLThanhVien.Name = "lblSLThanhVien";
            this.lblSLThanhVien.Size = new System.Drawing.Size(153, 20);
            this.lblSLThanhVien.TabIndex = 35;
            this.lblSLThanhVien.Text = "Số lượng thành viên:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(452, 42);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(252, 37);
            this.label28.TabIndex = 34;
            this.label28.Text = "Xem thành viên";
            // 
            // dataGridView7
            // 
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Location = new System.Drawing.Point(99, 128);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowHeadersWidth = 62;
            this.dataGridView7.RowTemplate.Height = 28;
            this.dataGridView7.Size = new System.Drawing.Size(963, 346);
            this.dataGridView7.TabIndex = 29;
            // 
            // FormQuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 635);
            this.Controls.Add(this.tab);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormQuanLy";
            this.Text = "Quản lý";
            this.tab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtTenMon;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbMonAn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Button btnCapnhatMon;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox txtLoai;
        private System.Windows.Forms.TextBox txtGiaInsert;
        private System.Windows.Forms.TextBox txtTenMonInsert;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtIDDH;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnCapNhatTT;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox txtDuongCN;
        private System.Windows.Forms.TextBox txtPhuongCN;
        private System.Windows.Forms.TextBox txtQuanCN;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnInsertCN;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.TextBox txtTPCN;
        private System.Windows.Forms.TextBox txtSDTCN;
        private System.Windows.Forms.TextBox txtTenCN;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox txtUpDuong;
        private System.Windows.Forms.TextBox txtUpPhuong;
        private System.Windows.Forms.TextBox txtUpQuan;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnUpdateCN;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.TextBox txtUpTP;
        private System.Windows.Forms.TextBox txtUpSDT;
        private System.Windows.Forms.TextBox txtUpTenCN;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cbChiNhanh;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cbTT;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.Label lblIDMon;
        private System.Windows.Forms.Label lblChinhanh;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnUpSoLuong;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label lblSLThanhVien;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.Button button1;
    }
}